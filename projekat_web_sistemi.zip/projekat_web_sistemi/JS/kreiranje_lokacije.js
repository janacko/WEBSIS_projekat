$(function () {

    //Uklanjanje disabled vlasništva za input za vremena do za sve dane u nedelji
    $('#minuti_od_pon').on("change", function (e) {
        $('#sati_do_pon').prop("disabled", false);
        $('#minuti_do_pon').prop("disabled", false);
    });

    $('#minuti_od_uto').on("change", function (e) {
        $('#sati_do_uto').prop("disabled", false);
        $('#minuti_do_uto').prop("disabled", false);
    });

    $('#minuti_od_sre').on("change", function (e) {
        $('#sati_do_sre').prop("disabled", false);
        $('#minuti_do_sre').prop("disabled", false);
    });

    $('#minuti_od_cet').on("change", function (e) {
        $('#sati_do_cet').prop("disabled", false);
        $('#minuti_do_cet').prop("disabled", false);
    });

    $('#minuti_od_pet').on("change", function (e) {
        $('#sati_do_pet').prop("disabled", false);
        $('#minuti_do_pet').prop("disabled", false);
    });

    $('#minuti_od_sub').on("change", function (e) {
        $('#sati_do_sub').prop("disabled", false);
        $('#minuti_do_sub').prop("disabled", false);
    });

    $('#minuti_od_ned').on("change", function (e) {
        $('#sati_do_ned').prop("disabled", false);
        $('#minuti_do_ned').prop("disabled", false);
    });

    //Pretvaranje sati i minuta u minute i dodavanje u JSON

    let radno_vreme = [];
    let dan;
    let vreme_od = 0;
    let vreme_do = 0;

    //Ponedeljak
    $('#minuti_do_pon').on("blur", function(e) {

        dan = "1";
        vreme_od = parseInt($('#sati_od_pon').val()) * 60 + parseInt($('#minuti_od_pon').val());
        vreme_do = parseInt($('#sati_do_pon').val()) * 60 + parseInt($('#minuti_do_pon').val());

        radno_vreme.push({
           "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
        console.log(radno_vreme);
    });

    //Utorak
    $('#minuti_do_uto').on("blur", function(e) {

        dan = "2";
        vreme_od = parseInt($('#sati_od_uto').val()) * 60 + parseInt($('#minuti_od_uto').val());
        vreme_do = parseInt($('#sati_do_uto').val()) * 60 + parseInt($('#minuti_do_uto').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
        console.log(radno_vreme);
    });

    //Sreda
    $('#minuti_do_sre').on("blur", function(e) {

        dan = "3";
        vreme_od = parseInt($('#sati_od_sre').val()) * 60 + parseInt($('#minuti_od_sre').val());
        vreme_do = parseInt($('#sati_do_sre').val()) * 60 + parseInt($('#minuti_do_sre').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
        console.log(radno_vreme);
    });

    //Četvrtak
    $('#minuti_do_cet').on("blur", function(e) {

        dan = "4";
        vreme_od = parseInt($('#sati_od_cet').val()) * 60 + parseInt($('#minuti_od_cet').val());
        vreme_do = parseInt($('#sati_do_cet').val()) * 60 + parseInt($('#minuti_do_cet').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
        console.log(radno_vreme);
    });

    //Petak
    $('#minuti_do_pet').on("blur", function(e) {

        dan = "5";
        vreme_od = parseInt($('#sati_od_pet').val()) * 60 + parseInt($('#minuti_od_pet').val());
        vreme_do = parseInt($('#sati_do_pet').val()) * 60 + parseInt($('#minuti_do_pet').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
        console.log(radno_vreme);
    });

    //Subota
    $('#minuti_do_sub').on("blur", function(e) {

        dan = "6";
        vreme_od = parseInt($('#sati_od_sub').val()) * 60 + parseInt($('#minuti_od_sub').val());
        vreme_do = parseInt($('#sati_do_sub').val()) * 60 + parseInt($('#minuti_do_sub').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
        console.log(radno_vreme);
    });

    //Nedelja
    $('#minuti_do_ned').on("blur", function(e) {

        dan = "7";
        vreme_od = parseInt($('#sati_od_ned').val()) * 60 + parseInt($('#minuti_od_ned').val());
        vreme_do = parseInt($('#sati_do_ned').val()) * 60 + parseInt($('#minuti_do_ned').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
        console.log(radno_vreme);
    });

    $('#forma_kreiranje_lokacije').on("submit", function (e) {
       e.preventDefault();

       //Ovde sad ide ajax za dodavanje lokacije
        $.ajax({
            "url": "https://vsis.mef.edu.rs/projekat/ulaznice/public_html/api/lokacija",
            "method": "POST",
            "timeout": 0,
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
                "Authorization": "Bearer " + localStorage.getItem("token")
            },
            "data": {
                "name": $('#naziv_lokacije').val(),
                "address": $('#adresa').val(),
                "city": $('#grad').val(),
                "description": $('#opis').val(),
                "workingHours": JSON.stringify(radno_vreme),
                "apitoken": $('meta[name="apitoken"]').attr("content")
            },
            "success": function (response) {
                console.log(response);
            },
            "error": function (response) {
                console.log(response);
            }
        });
    });
});