$(function() {

    $('#ime_prezime').on('blur', function(e) {
       let greska_ime_prezime = $('#greska_ime_prezime');
       let ispravnost_ime_prezime = /(?=^.{5,180}$)^[А-ЯЉЊШЂЧЋЖЏ][а-яčćžđšљњшђчћжџ]+(?:[\s-][А-ЯЉЊШЂЧЋЖЏ][а-яčćžđšљњшђчћжџ]+)+$|^[A-ZŠĐŽČĆ][a-zčćžđš]+(?:[\s-][A-ZŠĐŽČĆ][a-zčćžđš]+)+$/.test($(this).val());

        if (ispravnost_ime_prezime) {
            $(this).css("outline", "none");
            greska_ime_prezime.hide();
        }else {
            $(this).css("outline", "solid 3px #f72");
            greska_ime_prezime.show();
            greska_ime_prezime.html("Име и презиме није правилно написано").css('color', '#f72');

        }
    });

    $('#br_tel').on('blur', function(e) {
        let greska_br_tel = $('#greska_br_tel');
        let ispravnost_br_tel = /^[+][1-9][0-9][0-9]{9,14}$/.test($(this).val());

        if (ispravnost_br_tel || $(this).val() === '') {
            $(this).css("outline", "none");
            greska_br_tel.hide();
        }else {
            $(this).css("outline", "solid 3px #f72");
            greska_br_tel.show();
            greska_br_tel.html("Телефон није исправан").css('color', '#f72');

        }
    });

    $('#lozinka').on('blur', function(e) {
        let greska_lozinka = $('#greska_lozinka');
        let ispravnost_lozinke = /^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[^\w\d\s:])([^\s]){6,}$/.test($(this).val());

        if (ispravnost_lozinke) {
            $(this).css("outline", "none");
            greska_lozinka.hide();
        }else {
            $(this).css("outline", "solid 3px #f72");
            greska_lozinka.show();
            greska_lozinka.html("Лозинка није довољно јака").css('color', '#f72');

        }
    });

    $('#potvrda_lozinke').on('blur', function(e) {
        let lozinka = $('#lozinka').val();
        let potvrda_lozinke = $(this).val();
        let greska_potvrda_lozinke = $('#greska_potvrda_lozinke');

        if (lozinka === potvrda_lozinke) {
            $(this).css("outline", "none");
            greska_potvrda_lozinke.hide();
        }else {
            $(this).css("outline", "solid 3px #f72");
            greska_potvrda_lozinke.show();
            greska_potvrda_lozinke.html("Лозинке се не поклапају").css('color', '#f72');
        }
    });

    $('#uloga_korisnika').on("change", function(e){
        if($(this).val() === '2') {
            $('#izaberi_lokaciju').show();

        } else {
            $('#izaberi_lokaciju').hide();
        }
    });

    //Ovaj ajax izvlaci sve lokacije sa servera i ubacuje u izbor korisnika (u zavisnosti koju ulogu izabere) ako izabere ulogu blagajnik
    $.ajax({
        "url": "https://vsis.mef.edu.rs/projekat/ulaznice/public_html/api/lokacija?apitoken=" + $('meta[name="apitoken"]').attr("content"),
        "method": "GET",
        "timeout": 0,
        "headers": {
            "Accept": "application/json",
            "Authorization": "Bearer " +localStorage.getItem("token")
        },
        "success": function (response) {
            response.forEach((elem,index) => {
                $('#izaberi_lokaciju').append('<option value="' + elem.id + '"> ' + elem.naziv + ' </option>>');
            })
        },
        "error": function (response) {
            console.log(response);
        }
    });

    $('#forma_kreiranje_korisnika').on('submit', function(e) {
        e.preventDefault();

        let greska_email = $('#greska_email');
        let greska_kreiranje_korisnika = $('#greska_kreiranje_korisnika');

        //Vrednosti iz input polja
        let email = $('#email').val();
        let ime_prezime = $('#ime_prezime').val();
        let br_tel = $('#br_tel').val();
        let lozinka = $('#lozinka').val();
        let userRole = parseInt($('#uloga_korisnika').val()); 
        let lokacija = $('#izaberi_lokaciju').val();

        if(email === '') {
            $('#email').css("outline", "solid 3px #f72")
            greska_email.show();
            greska_email.html("Нисте унели имејл");
        } else {
            $('#email').css("outline", "none");
            greska_email.hide();
        }

        let form = new FormData();
        form.append("name", ime_prezime);
        form.append("email", email);
        form.append("phone", br_tel);
        form.append("password", lozinka);
        form.append("userRoleId", userRole);
        form.append("locationId", lokacija);
        form.append("apitoken", $('meta[name="apitoken"]').attr("content"));

        $.ajax({
            "url": "https://vsis.mef.edu.rs/projekat/ulaznice/public_html/api/korisnik",
            "method": "POST",
            "timeout": 0,
            "headers": {
                "Accept": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("token")
            },
            "processData": false,
            "mimeType": "multipart/form-data",
            "contentType": false,
            "dataType": "json",
            "data": form,
            "success": function(response) {
                if(response.error === undefined) {
                    console.log(response);
                    greska_kreiranje_korisnika.hide();
                    window.location = 'lista_svih_korisnika.html';
                } else {
                    greska_kreiranje_korisnika.show();
                    greska_kreiranje_korisnika.html(response.error).css("color", "#f00");// greska se ispod dugmeta pokazuje crvenom bojom
                }
            },
            "error": function(response) {
                greska_kreiranje_korisnika.show();
                greska_kreiranje_korisnika.html(response.error);
            }
        });
    });
});