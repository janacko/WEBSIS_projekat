$(function(){
	$.ajax({
		"url": "https://vsis.mef.edu.rs/projekat/ulaznice/public_html/api/korisnik?apitoken=" + $('meta[name="apitoken"]').attr("content"),
        "method": "GET",
        "timeout": 0,
        "headers": {
        	"Authorization": "Bearer " + localStorage.getItem("token")
        },
        "success":function(response){
        	console.log(response);
            let br_administratora = 0;
            let br_blagajnika = 0;
            let br_reg_korisnika = 0;
            let br_blokiranih_korisnika = 0;

			response.forEach((elem,index) => {
				if(elem.uloga.naziv === 'администратор') br_administratora++;
                else if (elem.uloga.naziv === 'благајник') br_blagajnika++;
                else if (elem.uloga.naziv === 'регистровани корисник') br_reg_korisnika++;
                else br_blokiranih_korisnika++;
            });
            $.ajax({
            	"url" : "https://vsis.mef.edu.rs/projekat/ulaznice/public_html/api/uloga?apitoken=" + $('meta[name="apitoken"]').attr("content"),
                "method": "GET",
                "timeout": 0,
                "headers": {
                	"Accept": "application/json",
                    "Authorization": "Bearer " + localStorage.getItem("token")
                },
                "success": function(response) {
                	let tabela_sadrzaj = $('#tabela-sadrzaj');
                    console.log(response);
                    response.forEach((elem,index) => {
                    	if(elem.naziv === 'администратор') {
                        tabela_sadrzaj.append('<tr>' +'<td>' + elem.id + '</td>' +  '<td>' + elem.naziv + '</td>' +  '<td>' + elem.opis +  '</td>'+ '<td>' + br_administratora +'</td>'+'</tr>');
                    } else if(elem.naziv === 'благајник') {
                    	tabela_sadrzaj.append('<tr>' +'<td>' + elem.id + '</td>' +  '<td>' + elem.naziv + '</td>' +  '<td>' + elem.opis +  '</td>'+ '<td>' + br_blagajnika +'</td>'+'</tr>');
                    } else if(elem.naziv === 'регистровани корисник') {
                    	tabela_sadrzaj.append('<tr>' +'<td>' + elem.id + '</td>' +  '<td>' + elem.naziv + '</td>' +  '<td>' + elem.opis +  '</td>'+ '<td>' + br_reg_korisnika +'</td>'+'</tr>');
                    } else {
                    	tabela_sadrzaj.append('<tr>' +'<td>' + elem.id + '</td>' +  '<td>' + elem.naziv + '</td>' +  '<td>' + elem.opis +  '</td>'+ '<td>' + br_blokiranih_korisnika +'</td>'+'</tr>');
                    }
                });
                },
                "error": function(response) {
                	console.log(response);
                }
            });
        },
        "error":function(response){
        	console.log(response);
        }
    });
});