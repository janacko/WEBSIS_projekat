$(function() {
    $('#naziv_lokacije').val(localStorage.getItem("lokacija_naziv"));
    $('#adresa').val(localStorage.getItem("lokacija_adresa"));
    $('#grad').val(localStorage.getItem("lokacija_grad"));
    $('#opis').val(localStorage.getItem("lokacija_opis"));

    //Pretvaranje sati i minuta u minute i dodavanje u JSON
    let radno_vreme = [];
    let dan;
    let vreme_od = 0;
    let vreme_do = 0;

    //Ponedeljak
    $('#minuti_do_pon').on("blur", function(e) {

        dan = "1";
        vreme_od = parseInt($('#sati_od_pon').val()) * 60 + parseInt($('#minuti_od_pon').val());
        vreme_do = parseInt($('#sati_do_pon').val()) * 60 + parseInt($('#minuti_do_pon').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });  
    });
    
    //Utorak
    $('#minuti_do_uto').on("blur", function(e) {

        dan = "2";
        vreme_od = parseInt($('#sati_od_uto').val()) * 60 + parseInt($('#minuti_od_uto').val());
        vreme_do = parseInt($('#sati_do_uto').val()) * 60 + parseInt($('#minuti_do_uto').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
    });

    //Sreda
    $('#minuti_do_sre').on("blur", function(e) {

        dan = "3";
        vreme_od = parseInt($('#sati_od_sre').val()) * 60 + parseInt($('#minuti_od_sre').val());
        vreme_do = parseInt($('#sati_do_sre').val()) * 60 + parseInt($('#minuti_do_sre').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
    });

    //Četvrtak
    $('#minuti_do_cet').on("blur", function(e) {

        dan = "4";
        vreme_od = parseInt($('#sati_od_cet').val()) * 60 + parseInt($('#minuti_od_cet').val());
        vreme_do = parseInt($('#sati_do_cet').val()) * 60 + parseInt($('#minuti_do_cet').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });    
    });

    //Petak
    $('#minuti_do_pet').on("blur", function(e) {

        dan = "5";
        vreme_od = parseInt($('#sati_od_pet').val()) * 60 + parseInt($('#minuti_od_pet').val());
        vreme_do = parseInt($('#sati_do_pet').val()) * 60 + parseInt($('#minuti_do_pet').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
    });

    //Subota
    $('#minuti_do_sub').on("blur", function(e) {

        dan = "6";
        vreme_od = parseInt($('#sati_od_sub').val()) * 60 + parseInt($('#minuti_od_sub').val());
        vreme_do = parseInt($('#sati_do_sub').val()) * 60 + parseInt($('#minuti_do_sub').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
    });

    //Nedelja
    $('#minuti_do_ned').on("blur", function(e) {

        dan = "7";
        vreme_od = parseInt($('#sati_od_ned').val()) * 60 + parseInt($('#minuti_od_ned').val());
        vreme_do = parseInt($('#sati_do_ned').val()) * 60 + parseInt($('#minuti_do_ned').val());

        radno_vreme.push({
            "dan": dan,
            "od": vreme_od,
            "do": vreme_do
        });
    });

    let forma_azuriranje = $("#forma_azuriranje");
    forma_azuriranje.on("submit", function (e) {
        e.preventDefault();

        let greska_azuriranje = $('#greska_azuriranje');
        let uspesno_azuriranje = $('#uspesno_azuriranje');


        $.ajax({
            "url": "https://vsis.mef.edu.rs/projekat/ulaznice/public_html/api/lokacija/" + localStorage.getItem("lokacija_id"),
            "method": "PATCH",
            "timeout": 0,
            "headers": {
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
                "Authorization": "Bearer " + localStorage.getItem("token")
            },
            "data": {
                "name": $('#naziv_lokacije').val(),
                "address": $('#adresa').val(),
                "city": $('#grad').val(),
                "description": $('#opis').val(),
                "workingHours": JSON.stringify(radno_vreme),
                "apitoken": $('meta[name="apitoken"]').attr("content")
            },
            "success": function (response) {
                console.log(response);
                greska_azuriranje.hide();
                uspesno_azuriranje.show();
                uspesno_azuriranje.html("Успешно си сачувао податке.").css("color", "#0f0");
            },
            "error": function (response) {
                console.log(response);
                uspesno_azuriranje.hide();
                greska_azuriranje.show();
                greska_azuriranje.html(response.responseJSON.message).css("color", "#f00");
            }
        });
    });
});